Please use the following datasets and suggested capacity values to test your project. 

* Project - first part
Three data sets
- input_vertices_1.pts   capacity:1 or 2
- input_vertices_2.pts	 capacity:1 or 2
- input_vertices_3.pts	 capacity:1 or 2 